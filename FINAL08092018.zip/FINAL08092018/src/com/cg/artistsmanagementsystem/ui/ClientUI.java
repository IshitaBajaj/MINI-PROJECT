package com.cg.artistsmanagementsystem.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.artistsmanagementsystem.bean.UserBean;
import com.cg.artistsmanagementsystem.exception.AdminException;
import com.cg.artistsmanagementsystem.service.AdminServiceImpl;
import com.cg.artistsmanagementsystem.service.IAdminService;
import com.cg.artistsmanagementsystem.service.IUserService;
import com.cg.artistsmanagementsystem.service.UserServiceImpl;
/*
 * MAIN CLASS-ClientUI
 */
public class ClientUI {

	public static Logger logger=Logger.getRootLogger();//Logger for tracking the state of application
	public static void main(String[] args) {
		
		int option;
		char choice='y';
		Scanner scanner=new Scanner(System.in);
		/*
		 * Main Menu of the Application 
		 * 1.Login: Displays the menu for admin or user as per the provided credentials
		 * 2.Exit: Terminated the Application
		 * The application runs until the admin/user explicitly exits the run application
		 */
		System.out.println("*******************************************************************");
		System.out.println("           MEDIA COMPOSER AND ARTISTS MANAGEMENT SYSTEM");
		System.out.println("******************************************************************");
		System.out.println("Menu:");
		System.out.println("1.Login");
		System.out.println("2.Exit");
		
		do
		{
			try
			{
			System.out.print("Enter Your Choice:");
			option=(int)scanner.nextInt();
			
			switch(option)
			{
				case 1:	IAdminService adminService=new AdminServiceImpl();
						try{
							System.out.print("Enter Login Id: ");
							int id=scanner.nextInt();
							System.out.print("Enter Password: ");
							String pwd=scanner.next();
							UserBean user=new UserBean();
						
							user.setUserId(id);
							user.setUserPwd(pwd);
							String type=adminService.login(user);
							if("A".equals(type))
							{
								System.out.println("Login Successful!");
								logger.info("Admin Logged In!");
								new AdminUI(user).adminMenu();
							}
							else if("U".equals(type)){
								System.out.println("Login Successful!");
								logger.info("User Logged In!");
								new UserUI().userMenu();
							}
							else
							{	System.out.flush();
								System.err.flush();
								System.err.println("Invalid Username/Password!");
								logger.warn("Invalid Credentials!");
							}
						}
						catch(InputMismatchException e)
						{	System.err.flush();
							System.err.println("Enter Integer Only!\n");
							logger.error("Invalid Inputs");
						}catch (Exception e) {
							e.printStackTrace();
							System.err.flush();
							System.err.println(e);;
							logger.error(e);
						}
						
						break;
				
				case 2: System.out.println("Application Terminated!");
						logger.info("Application Terminated!");
						System.exit(0);
						break;
				default:System.err.print("Please Enter a Valid Option!\n");		
						ClientUI.main(null);
			}
			scanner.nextLine();
			}
			catch(InputMismatchException e)
			{
				System.out.flush();
				System.err.println("Please Enter a Valid Option!");
				scanner.next();
				ClientUI.main(null);
				
			}
			
			System.out.print("Do you want to continue? Press 'N' to exit else to continue. ");
			choice=scanner.next().charAt(0);
					}while(choice!='N'&&choice!='n');
}
	


}
