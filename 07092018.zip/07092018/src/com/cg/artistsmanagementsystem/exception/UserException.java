package com.cg.artistsmanagementsystem.exception;

public class UserException extends Exception{

	public UserException(String message)
	{
		super(message);
	}
}
