package com.cg.artistsmanagementsystem.service;

import java.util.ArrayList;

import com.cg.artistsmanagementsystem.bean.ArtistBean;
import com.cg.artistsmanagementsystem.bean.ComposerBean;
import com.cg.artistsmanagementsystem.bean.SongBean;
import com.cg.artistsmanagementsystem.dao.DaoUserImpl;
import com.cg.artistsmanagementsystem.dao.IDaoUser;
import com.cg.artistsmanagementsystem.exception.UserException;

public class UserServiceImpl implements IUserService {
	IDaoUser userDao=null;
	
	@Override
	public ArrayList<SongBean> searchComposerSongAssoc(int composerId) throws UserException  {
		userDao=new DaoUserImpl();
		ArrayList<SongBean> list=userDao.searchComposerSongAssoc(composerId);
		return list;
	}

	@Override
	public ArrayList<SongBean> searchArtistSongAssoc(int artistId) throws UserException  {
		userDao=new DaoUserImpl();
		ArrayList<SongBean> list=userDao.searchArtistSongAssoc(artistId);
		return list;
}

	@Override
	public ComposerBean searchComposer(int composerId) throws UserException {
		userDao=new DaoUserImpl();
		ComposerBean composer=userDao.searchComposer(composerId);	
		return composer;
	}

	@Override
	public ArtistBean searchArtist(int artistId) throws UserException {
		userDao=new DaoUserImpl();
		ArtistBean artist=userDao.searchArtist(artistId);
		return artist;
	}

	@Override
	public ArrayList<Integer> getComposerList() throws UserException {
		userDao=new DaoUserImpl();
		ArrayList<Integer> composerList=userDao.getComposerList();	
		return composerList;
	}

	@Override
	public ArrayList<Integer> getArtistList() throws UserException {
		userDao=new DaoUserImpl();
		ArrayList<Integer> artistList=userDao.getArtistList();	
		return artistList;
	}

	@Override
	public boolean validateId(int composerId) {
		if(composerId>0 && composerId<999999)
			return true;
		else 
			return false;
	}
}
