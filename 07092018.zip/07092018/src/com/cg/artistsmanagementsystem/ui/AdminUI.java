package com.cg.artistsmanagementsystem.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.artistsmanagementsystem.bean.ArtistBean;
import com.cg.artistsmanagementsystem.bean.ComposerBean;
import com.cg.artistsmanagementsystem.bean.UserBean;
import com.cg.artistsmanagementsystem.exception.AdminException;
import com.cg.artistsmanagementsystem.service.AdminServiceImpl;
import com.cg.artistsmanagementsystem.service.IAdminService;

public class AdminUI {
	static IAdminService adminService=null;
    static Scanner scanner=null;
    ComposerBean composer=null;
    ArtistBean artist=null;
    UserBean admin=null;
    AdminUI(UserBean admin)
    {	
    	this.admin=admin;
    	System.out.println("------------------------------ADMIN MENU------------------------------");
    	System.out.println("1.Search Composer");
		System.out.println("2.Add Composer");
		System.out.println("3.Edit Composer");
		System.out.println("4.Search Artist");
		System.out.println("5.Add Artist");
		System.out.println("6.Edit Artist");
		System.out.println("7.Assosciate Songs");
		System.out.println("8.Logout");
		System.out.println("9.Exit");
		System.out.println("-----------------------------------------------------------------------");
		System.out.print("Enter choice: ");
    }
	public AdminUI() {
		
	}
	public void adminMenu() 
	{	int option;
		scanner=new Scanner(System.in);
		try
		{	
			option=scanner.nextInt();
			switch(option)
			{
			case 1:	adminService=new AdminServiceImpl();
					scanner=new Scanner(System.in);
					boolean bool=false;
					do{
						try 
						{
						System.out.print("Enter Composer Id to be Searched:");
						int composerId=scanner.nextInt();
						bool=true;
							composer=new ComposerBean();
							composer=adminService.searchComposer(composerId);
							if(composer!=null)
								System.out.println(composer);
							else
								System.out.println("No Composer Found!!!");
						} 
						catch (AdminException e)
						{
							System.err.flush();
							System.err.print(e);
							scanner.next();
						}
						catch(InputMismatchException e)
						{	
							System.err.println("Composer Id should be Integer!");
							System.err.flush();
							scanner.next();
						}
					}while(bool==false);
					
					System.err.flush();
					new AdminUI(admin).adminMenu();
					break;
			
			case 2: adminService=new AdminServiceImpl();
					try 
				    {	
						composer=populateComposer();
						
				    		if(composer!=null)
				    		{	
				    			int id=adminService.addComposer(composer,admin);
				    				if(id!=-1)
				    					System.out.println("Composer Sucessfully Added With Id: "+id+"!");
				    				else
				    					System.out.println("Composer Not Added!");
				    		}		
				    } 
				    catch (AdminException e) 
				    {
							System.err.println(e);
				    }
					
			        System.err.flush();
			        new AdminUI(admin).adminMenu();
				break;
			case 3: 
					updateComposer(admin);
					/*scanner=new Scanner(System.in);
					
					try 
					{	
						System.out.print("Enter the Id of Composer:");
						int id=scanner.nextInt();
						composer=new ComposerBean();
						composer=adminService.searchComposer(id);
						if(composer!=null)
						{	
							System.out.println("What do you want to update?");
							System.out.println("1.Composer Name\n2.Composer Born Date\n3.Composer Died Date");
							System.out.println("4.Composer Caeipi Number\n5.Composer Music Society");
							System.out.print("Enter Choice: ");
							try
							{
								int choice=scanner.nextInt();
								switch(choice)
								{
								case 1: System.out.print("Enter new Composer name: ");
										BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
										String composerName = buffer.readLine();
								        if(adminService.validateName(composerName))
								        {	
								        	composer.setComposerName(composerName);
								        	if(adminService.updateComposerName(composer,admin))
								        		System.out.println("Composer Name Updated Successfully!");
								        	else
								        		System.out.println("Composer Name Not Updated!");
								        }
								        else
								        	System.err.println("Enter a Valid Name!");
								        break;
								case 2: System.out.print("Enter New Composer Born Date(dd/mm/yyyy): ");
										String bornDate=scanner.next();
										if(adminService.validateDate(bornDate))
										{
											composer.setComposerBornDate(bornDate);
											if(adminService.updateComposerBornDate(composer,admin))
												System.out.println("Composer Born Date Updated Successfully!");
											else
												System.out.println("Composer Born Date Not Updated!");
										}
										else
											System.err.println("Enter the Date in Correct Format!");
										break;
								case 3:	System.out.print("Enter New Composer Died Date(dd/mm/yyyy)(NA if not applicable): ");
										String diedDate=scanner.next();
										if(adminService.validateDate(diedDate))
										{		if(diedDate.equals("NA"))
													diedDate=null;
											composer.setComposerDiedDate(diedDate);
											if(adminService.updateComposerDiedDate(composer,admin))
												System.out.println("Composer Died Date Updated Successfully!");
											else
												System.out.println("Composer Died Date Not Updated!");
										}
										else
											System.err.println("Enter the Date in Correct Format!");
										break;
								case 4:	System.out.print("Enter New Composer Caepei Number: ");
										String number=scanner.next();
										if(adminService.validateCaeipiNumber(number))
										{
											composer.setComposerCaeipiNumber(number);
											if(adminService.updateComposerCaeipiNumber(composer,admin))
												System.out.println("Composer Caeipi Number Updated Successfully!");
											else
												System.out.println("Composer Caeipi Number Not Updated!");
										}
										else
											System.err.println("Enter a Valid CaeipiNumber!");
									break;
								case 5:System.out.print("Enter New Music Society Id(100/101/000):");
										String societyId=scanner.next();
										if("100".equals(societyId)||"101".equals(societyId))
											composer.setComposerMusicSocietyID(societyId);
										else
											composer.setComposerMusicSocietyID("000");
										if(adminService.updateComposerMusicSocietyId(composer,admin))
											System.out.println("Composer Music Society Id Updated Successfully!");
										else
											System.out.println("Composer Music Society Not Updated!");
									break;
								
								default:System.out.println("Invalid Option!");
								}
							}catch(InputMismatchException e)
							{
								System.err.println("Enter Correct Option!");
							}
						}	
						else
							System.out.println("No Composer Found!!!");
					} 
					catch (AdminException e)
					{
						System.out.print(e);
					}
					catch(InputMismatchException e)
					{
						System.err.println("Composer Id should be Numeric!");
					}*/
					new AdminUI(admin).adminMenu();
					System.err.flush();				
				break;
			case 4:	adminService=new AdminServiceImpl();
					scanner=new Scanner(System.in);
					try {
						System.out.print("Enter the Artist Id to be Searched: ");
						int artistId=scanner.nextInt();
						artist=adminService.searchArtist(artistId);
						if(artist!=null)
							System.out.println(artist);
						else
							System.out.println("No Artist Found!!!");
					} 
					catch (AdminException e)
					{
						System.err.println(e);
					}
					System.err.flush();
					new AdminUI(admin).adminMenu();
				break;
			case 5:	adminService=new AdminServiceImpl();
					try 
			        {		artist=populateArtist();
			        		if(artist!=null)
			        		{
			        			int id=adminService.addArtist(artist,admin);
			        			if(id!=-1)
			        				System.out.println("Artist Sucessfully Added With Id: "+id+"!");
			        			else
			        				System.out.println("Artist Not Added!");
			        		}
			        
			        }
			        catch (AdminException e) 
			        {
							System.out.println(e);
			        }
					
			        new AdminUI(admin).adminMenu();
						break;
			case 6: updateArtist(admin);/*adminService=new AdminServiceImpl();
					scanner=new Scanner(System.in);
					try 
					{	
						System.out.print("Enter the Id of Artist:");
						int id=scanner.nextInt();
						artist=new ArtistBean();
						artist=adminService.searchArtist(id);
						if(artist!=null)
						{	
							System.out.println("What do you want to update?");
							System.out.println("1.Artist Name\n2.Artist Type\n3.Artist Born Date\n4.Composer Died Date");
							System.out.print("Enter Choice: ");
							try
							{
								int choice=scanner.nextInt();
								switch(choice)
								{
								case 1: System.out.print("Enter new Artist name: ");
										BufferedReader buffer1 = new BufferedReader(new InputStreamReader(System.in));
										String name = buffer1.readLine();
								        if(adminService.validateName(name))
								        {	
								        	artist.setArtistName(name);
								        	if(adminService.updateArtistName(artist,admin))
								        		System.out.println("Artist Name Updated Successfully!");
								        	else
								        		System.out.println("Artist Name Not Updated!");
								        }
								        else
								        	System.err.println("Enter a Valid Name!");
										      break;
								case 2: System.out.print("Enter New Artist Type(1 Character): ");
										String s=scanner.next();
										if(adminService.validateType(s))
										{
											artist.setArtistType(s);
											if(adminService.updateArtistType(artist,admin))
												System.out.println("Artist Type Updated Successfully!");
											else
												System.out.println("Artist Type Not Updated");
										}
										else
											System.err.println("Type Must Be Of 1 Character!");
									break;	
								case 3: System.out.print("Enter Artist Born Date(dd/mm/yyyy): ");
										String bornDate=scanner.next();
										if(adminService.validateDate(bornDate))
										{
											artist.setArtistBornDate(bornDate);
											if(adminService.updateArtistBornDate(artist,admin))
												System.out.println("Artist Born Date Updated Successfully!");
											else
												System.out.println("Artist Born Date Not Updated!");
										}
										else
											System.err.println("Enter the Date in Correct Format!");
									break;
								case 4:	System.out.print("Enter Died Date(dd/mm/yyyy)(NA if not Applicable): ");
										String diedDate=scanner.next();
										if(adminService.validateDate(diedDate))
										{		if(diedDate.equals("NA"))
													diedDate=null;
											artist.setArtistDiedDate(diedDate);
											if(adminService.updateArtistDiedDate(artist,admin))
												System.out.println("Artist Died Date Updated Successfully!");
											else
												System.out.println("Artist Died Date Not Updated!");
										}
										else
											System.err.println("Enter the Date in Correct Format!");
									break;
								default:System.out.println("Enter Valid Option!");	
								}
								}
							catch(InputMismatchException e)
							{
									System.err.println("Enter Correct Option!");
							}
						}
						else
							System.out.println("No Artist Found!");
					}catch(InputMismatchException e)
					{
							System.err.println("Artist Id Should Be Numeric!");
					}
					catch(AdminException e)
					{
						System.err.println(e);
					}
					System.err.flush();*/
					new AdminUI(admin).adminMenu();
				break;
			case 7:	adminService=new AdminServiceImpl();
					scanner=new Scanner(System.in);
					try{
						System.out.println("1.Assosciate Song With Composer");
						System.out.println("2.Assosciate Song With Artist");
						System.out.print("Enter Choice: ");
						int choice=scanner.nextInt();
						switch(choice)
						{
						case 1: System.out.print("Enter Composer Id: ");
								try
								{
									int composerId=scanner.nextInt();
									ComposerBean composer=adminService.searchComposer(composerId);
									if(composer!=null)
									{
										System.out.print("Enter Song Id: ");
										int songId=scanner.nextInt();
										if(adminService.searchSong(songId))
											if(adminService.associateComposer(composerId,songId,admin))
												System.out.println("Composer Assosciated With Song Sucessfully!");
											else
												System.out.println("Composer Not Assosciated With Song!");
										else
											System.out.println("Song not Found in the Database!");
									}
									else
										System.out.println("No Composer Found!");
								}catch(AdminException e)
								{
									System.out.println(e);
								}
								catch(InputMismatchException e)
								{
									System.err.println("Composer Id Should Be Numeric");
								}
							break;
							
						case 2: System.out.print("Enter Artist Id: ");
								try
								{
									int artistId=scanner.nextInt();
									ArtistBean artist=adminService.searchArtist(artistId);
									if(artist!=null)
									{	
										System.out.println("Enter Song Id: ");
										int songId=scanner.nextInt();
										if(adminService.searchSong(songId))
											if(adminService.associateArtist(artistId, songId, admin))
												System.out.println("Artist Assosciated With Song Successfully!");
											else
												System.out.println("Artist Not Assosciated With Song!");
										else
											System.out.println("Song Not Found in the Database!");
									}
									else
										System.out.println("No Artist Found!");
								}
								catch(AdminException e)
								{
									System.out.println(e);
								}
								catch(InputMismatchException e)
								{
									System.err.println("Artist Id Should Be Numeric!");
								}
								break;
						default:System.out.println("Enter Valid Option!");
								break;
						}		
						}catch(InputMismatchException e)
						{
							System.err.println("Enter Valid Option!");
						}
						System.err.flush();
						new AdminUI(admin).adminMenu();
						break;
			case 8:	ClientUI.main(null);
					break;
			case 9:	System.out.print("Application Terminated!");
					System.exit(0);
					break;
			default: System.err.flush();
					 System.err.println("Enter a valid option!");
					 new AdminUI(admin).adminMenu();;
			}
		}
		catch(Exception e)
		{	System.err.flush();
			System.err.println("Enter a Valid Option!");
			new AdminUI(admin).adminMenu();
		}
		
		
		
	}
	
	
	
	
	
	
	public static ComposerBean populateComposer() throws IOException
	{	
		adminService=new AdminServiceImpl();
		scanner=new Scanner(System.in);
		ComposerBean composer=new ComposerBean();
		String name,number,societyId,bornDate,diedDate;
		int i=0;
		System.out.println("Enter the details of new composer:");
		do
		{
			System.out.print("Enter Composer Name(Max 50 Characters): ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			name = br.readLine();
			if(adminService.validateName(name))
				i=1;
			else
				System.out.println("Invalid Name! Enter Again!");
		}while(i!=1);
			
			composer.setComposerName(name);
			int check=0;
		do
		{
			i=0;
			do
			{
				System.out.print("Enter Composer Born Date(dd/mm/yyyy): ");
				bornDate=scanner.next();
				if(adminService.validateDate(bornDate))
					i=1;
				else
					System.out.println("Invalid Date! Enter Again!");
			}while(i!=1);	
				i=0;	
				composer.setComposerBornDate(bornDate);
					
			do
			{
				System.out.print("Enter Died Date(dd/mm/yyyy)(NA if not Applicable): ");
				diedDate=scanner.next();
				if(adminService.validateDate(diedDate))
					i=1;
				else
					System.out.println("Invalid Date! Enter Again!");
			}while(i!=1);	
				
						if(diedDate.equals("NA"))
							diedDate=null;
					composer.setComposerDiedDate(diedDate);
					
				check=adminService.validateDates(bornDate,diedDate);
				if(check==0)
					System.out.println("Born Date Should Be Before Today's Date & Died Date Should Be After Born Date!\nEnter Again!");
					
		}while(check!=1);			
		
		do
		{
			System.out.print("Enter Composer Caeipi Number(Max 10 Digits):");
			number=scanner.next();
			if(adminService.validateCaeipiNumber(number))
				i=1;
			else
				System.out.println("Invalid Caeipi Number! Enter Again!");
		}while(i!=1);
			
			composer.setComposerCaeipiNumber(number);
			i=0;
		do
		{
			System.out.print("Enter Music Society ID(100/101/000): ");
			societyId=scanner.next();
			if(adminService.validateMusicSociety(societyId))
				i=1;
			else
				System.out.println("Invalid Society Id! Enter Again!");
		}while(i!=1);	
				
		composer.setComposerMusicSocietyID(societyId);
			
		
        return composer;
	}
	
	public static ArtistBean populateArtist() throws IOException
	{
		adminService=new AdminServiceImpl();
		scanner=new Scanner(System.in);
		ArtistBean artist=new ArtistBean();
		String artistName,type,bornDate,diedDate;
		int i=0;
		
		System.out.println("Enter the Details of New Artist:");
		
		do
		{	
			System.out.print("Enter Artist Name(Max 50 Characters): ");
			BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
			artistName = buffer.readLine();
			if(adminService.validateName(artistName))
				i=1;
			else
				System.out.println("Invalid Artist Name! Enter Again!");
		}while(i!=1);
		
			i=0;
			artist.setArtistName(artistName);
		
		do
		{	
        	System.out.print("Enter Artist Type(1 Character): ");
        	type=scanner.next();
        	if(adminService.validateType(type.toUpperCase()))
        			i=1;
        	else
        		System.out.println("Invalid Type! Enter Again!");
		}while(i!=1);
        
				        artist.setArtistType(type);
	    
	        int check=0;
	     do
	     {	
	    	 i=0;

		     do
			 {
		    	System.out.print("Enter Artist Born Date(dd/mm/yyyy): ");
				bornDate=scanner.next();
					if(adminService.validateDate(bornDate))
							i=1;
					else
						System.out.println("Invalid Date! Enter Again!");
			    }while(i!=1);
						
		     			i=0;
						
			
			do{
				System.out.print("Enter Died Date(dd/mm/yyyy)(NA if not Applicable): ");
				diedDate=scanner.next();
				if(adminService.validateDate(diedDate))
						i=1;
				else
					System.out.println("Invalid Date! Enter Again!");
			}while(i!=1);
		
				if(diedDate.equals("NA"))
					diedDate=null;
				
			check=adminService.validateDates(bornDate,diedDate);
				if(check==0)
					System.out.println("Born Date Should Be Before Today's Date & Died Date Should Be After Born Date!\nEnter Again!");
				
				
	     }while(check!=1);		
	     
	    artist.setArtistBornDate(bornDate);
	    artist.setArtistDiedDate(diedDate);
		
	    System.err.flush();
       
	    return artist;

	}
	
	public static void updateComposer(UserBean admin) throws IOException
	{	adminService=new AdminServiceImpl();
		scanner=new Scanner(System.in);
		String composerName;
		ComposerBean composer=new ComposerBean();;
		int choice=0,flag=0;
		String bornDate,number,diedDate,societyId;
		do
		{	
			try 
			{	flag=0;
				System.out.print("Enter the Id of Composer:");
				int id=scanner.nextInt();
					flag=1;
				composer=adminService.searchComposer(id);
			}	
			catch (AdminException e)
			{
				System.out.print(e);
			}
			catch(InputMismatchException e)
			{
				System.err.println("Composer Id should be Numeric!");
				System.err.flush();
				scanner.next();
			}
		}while(flag!=1);	
				
		if(composer!=null)
		{	flag=0;
			System.out.println("What do you want to update?");
			System.out.println("1.Composer Name\n2.Composer Born Date\n3.Composer Died Date");
			System.out.println("4.Composer Caeipi Number\n5.Composer Music Society\n6.Return to Previous Menu\n7.Exit");
			do
			{
				try
				{	System.out.print("Enter Choice: ");
					choice=scanner.nextInt();
					switch(choice)
					{
					case 1: do{
								System.out.print("Enter new Composer name: ");
								BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
								composerName = buffer.readLine();
						        if(adminService.validateName(composerName))
						        	flag=1;
						        else
									System.out.println("Invalid Name! Enter Again!");
							}while(flag!=1);
					        flag=0;	
								composer.setComposerName(composerName);
					        	if(adminService.updateComposerName(composer,admin))
					        		System.out.println("Composer Name Updated Successfully!");
					        	else
				        		System.out.println("Composer Name Not Updated!");
					      
					        	break;
					case 2: do{
								System.out.print("Enter New Composer Born Date(dd/mm/yyyy): ");
								bornDate=scanner.next();
									if(adminService.validateDate(bornDate))
										flag=1;
									else
										System.out.println("Invalid Date! Enter Again!");
							}while(flag!=1);
							flag=0;
							composer.setComposerBornDate(bornDate);
							if(adminService.updateComposerBornDate(composer,admin))
								System.out.println("Composer Born Date Updated Successfully!");
							else
								System.out.println("Composer Born Date Not Updated!");
							break;
					case 3:	do{
								System.out.print("Enter New Composer Died Date(dd/mm/yyyy)(NA if not applicable): ");
								diedDate=scanner.next();
								if(adminService.validateDate(diedDate))
									flag=1;
								else
									System.out.println("Invalid Date! Enter Again!");
							}while(flag!=1);
							flag=0;
							if(diedDate.equals("NA"))
								diedDate=null;
							
							composer.setComposerDiedDate(diedDate);
							
							if(adminService.updateComposerDiedDate(composer,admin))
								System.out.println("Composer Died Date Updated Successfully!");
							else
								System.out.println("Composer Died Date Not Updated!");
							break;
							
					case 4:	do{
								System.out.print("Enter New Composer Caepei Number: ");
								number=scanner.next();
								if(adminService.validateCaeipiNumber(number))
									flag=1;
								else
									System.out.println("Invalid Caeipi Number! Enter Again!");
							}while(flag!=1);	
							
							flag=0;
							composer.setComposerCaeipiNumber(number);
								
							if(adminService.updateComposerCaeipiNumber(composer,admin))
								System.out.println("Composer Caeipi Number Updated Successfully!");
							else
								System.out.println("Composer Caeipi Number Not Updated!");
							break;
							
					case 5: do{
								System.out.print("Enter New Music Society Id(100/101/000):");
								societyId=scanner.next();
								if(adminService.validateMusicSociety(societyId))
									flag=1;
								else
									System.out.println("Invalid Music Society Id! Enter Again!");
							}while(flag!=1);
								
							if(adminService.updateComposerMusicSocietyId(composer,admin))
								System.out.println("Composer Music Society Id Updated Successfully!");
							else
								System.out.println("Composer Music Society Not Updated!");
							
							break;
					case 6: new AdminUI(admin).adminMenu();
							break;
							
					case 7: System.exit(0);
							break;
									
					default:System.out.println("Invalid! Enter Correct Option!");
					}
				}catch(InputMismatchException e)
				{
					System.err.println("Enter Correct Option!");
					scanner.next();
				}
				catch(AdminException e)
				{
					System.err.println(e+"Updation Could Not Be Completed! Please Try Again!");
					scanner.next();
				}
			}while(choice<1||choice>5);
		}	
		else
			System.out.println("No Composer Found!!!");
		
		
	}
	
	public static void updateArtist(UserBean admin) throws IOException
	{
		adminService=new AdminServiceImpl();
		scanner=new Scanner(System.in);
		ArtistBean artist=new ArtistBean();
		int choice=0,flag=0;
		String name,s,bornDate,diedDate;
		do{
			flag=0;
			try 
			{	
				System.out.print("Enter the Id of Artist:");
				int id=scanner.nextInt();
					flag=1;
				artist=adminService.searchArtist(id);
			}
			catch(InputMismatchException e)
			{
					System.err.println("Artist Id Should Be Numeric!");
			}
			catch(AdminException e)
			{
				System.err.println(e);
			}
		}while(flag!=1);	
				
		if(artist!=null)
		{				
			flag=0;
			System.out.println("What do you want to update?");
			System.out.println("1.Artist Name\n2.Artist Type\n3.Artist Born Date\n4.Composer Died Date");
			do
			{
				System.out.print("Enter Choice: ");
				try
				{
					choice=scanner.nextInt();
					switch(choice)
					{
					case 1: do
							{
							System.out.print("Enter new Artist name: ");
							BufferedReader buffer1 = new BufferedReader(new InputStreamReader(System.in));
							name = buffer1.readLine();
					        if(adminService.validateName(name))
					        		flag=1;
					        else
					        	System.out.println("Invalid Name! Enter Again!");
							}while(flag!=1);
					        	
								flag=0;
								artist.setArtistName(name);
					        	if(adminService.updateArtistName(artist,admin))
					        		System.out.println("Artist Name Updated Successfully!");
					        	else
					        		System.out.println("Artist Name Not Updated!");
					       
					         break;
					case 2: do
							{
							System.out.print("Enter New Artist Type(1 Character): ");
								s=scanner.next();
								if(adminService.validateType(s))
									flag=1;
								else
									System.out.println("Type Must Be Of 1 Character! Enter Again!");
							}while(flag!=1);	
								flag=0;
							artist.setArtistType(s);
								if(adminService.updateArtistType(artist,admin))
									System.out.println("Artist Type Updated Successfully!");
								else
									System.out.println("Artist Type Not Updated");
						
						break;
						
					case 3: do
							{
								System.out.print("Enter Artist Born Date(dd/mm/yyyy): ");
								bornDate=scanner.next();
								if(adminService.validateDate(bornDate))
									flag=1;
								else
									System.out.println("Invalid Date! Enter Again!");
							}while(flag!=1);	
								flag=0;
								artist.setArtistBornDate(bornDate);
								if(adminService.updateArtistBornDate(artist,admin))
									System.out.println("Artist Born Date Updated Successfully!");
								else
									System.out.println("Artist Born Date Not Updated!");
						break;
						
					case 4:	do
							{
							System.out.print("Enter Died Date(dd/mm/yyyy)(NA if not Applicable): ");
							diedDate=scanner.next();
							if(adminService.validateDate(diedDate))
									flag=1;
							else
								System.out.println("Invalid Date! Enter Again!");
							}while(flag!=1);
								
								if(diedDate.equals("NA"))
										diedDate=null;
								artist.setArtistDiedDate(diedDate);
								if(adminService.updateArtistDiedDate(artist,admin))
									System.out.println("Artist Died Date Updated Successfully!");
								else
									System.out.println("Artist Died Date Not Updated!");
						break;
				default:System.out.println("Enter Valid Option!");	
					}
					}
				catch(InputMismatchException e)
					{
						System.err.println("Enter Correct Option!");
						scanner.next();
				}
				catch(AdminException e)
				{
					System.err.println(e+"Updation Could Not Be Completed! Please Try Again!");
					scanner.next();
				}
			}while(choice<1||choice>4);
		}
			else
			System.out.println("No Artist Found!");
				System.err.flush();
	}	
 }
