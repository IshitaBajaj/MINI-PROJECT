/**
 * 
 */
package com.cg.artistsmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.artistsmanagementsystem.bean.ArtistBean;
import com.cg.artistsmanagementsystem.bean.ComposerBean;
import com.cg.artistsmanagementsystem.bean.SongBean;
import com.cg.artistsmanagementsystem.bean.UserBean;
import com.cg.artistsmanagementsystem.exception.AdminException;
import com.cg.artistsmanagementsystem.exception.UserException;

/**
 * @author ibajaj
 *
 */
public class DaoUserImpl implements IDaoUser{
	Connection con=null;
	boolean status;
	String userPwd;
	
	@Override
	public ComposerBean searchComposer(int composerId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ArtistBean searchArtist(int artistId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ArrayList<SongBean> searchComposerSongAssoc(int composerId) throws UserException {
		ArrayList<SongBean> list=new ArrayList<>();
		try{
			con=DBUtil.getConnection();
			PreparedStatement preparedStatement=con.prepareStatement(IQueryMapper.SEARCH_COMPOSER_SONGASSOC);
			preparedStatement.setInt(1, composerId);
			
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				SongBean song=new SongBean();
				song.setSongId(resultSet.getInt(1));
				song.setSongName(resultSet.getString(2));
				song.setSongDuration(resultSet.getString(3));
				list.add(song);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			throw new UserException(e.getMessage()+"\n Song Not Found!");
		}
		return list;
	}

	@Override
	public ArrayList<SongBean> searchArtistSongAssoc(int artistId) throws UserException {
		ArrayList<SongBean> list=new ArrayList<>();
		try{
			con=DBUtil.getConnection();
			PreparedStatement preparedStatement=con.prepareStatement(IQueryMapper.SEARCH_ARTIST_SONGASSOC);
			preparedStatement.setInt(1, artistId);
			
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				SongBean song=new SongBean();
				song.setSongId(resultSet.getInt(1));
				song.setSongName(resultSet.getString(2));
				song.setSongDuration(resultSet.getString(3));
				list.add(song);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			throw new UserException(e.getMessage()+"\n Song Not Found!");
		}
		return list;
	}

	

}
