package com.cg.artistsmanagementsystem.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.artistsmanagementsystem.bean.ArtistBean;
import com.cg.artistsmanagementsystem.bean.ComposerBean;
import com.cg.artistsmanagementsystem.bean.SongBean;
import com.cg.artistsmanagementsystem.bean.UserBean;
import com.cg.artistsmanagementsystem.exception.AdminException;
import com.cg.artistsmanagementsystem.service.AdminServiceImpl;
import com.cg.artistsmanagementsystem.service.IAdminService;

/**
 * @author ibajaj
 *
 */
public class UserUI {
	static IAdminService adminService=null;
    static Scanner scanner=null;
    ComposerBean composer=null;
    ArtistBean artist=null;
    UserBean admin=null;
	UserUI()
	{
		System.out.println("------------------------------USER MENU------------------------------");
    	System.out.println("1.Search Songs");
		System.out.println("2.Return to the Main Menu");
		System.out.println("3.Exit");
		System.out.println("-----------------------------------------------------------------------");
		System.out.print("Enter choice: ");
	}

	public void userMenu() {
		int option;
		scanner=new Scanner(System.in);
		try{
			option=scanner.nextInt();
			switch(option)
			{
			case 1:	ArrayList<SongBean> list=new ArrayList<>();
					list=searchSong();
					if(list==null)
						System.out.println("Composer Does Not Exists!");
					else if(list.isEmpty())
						System.out.println("No Songs Associated With Given Composer Id!");
					else
					{
						Iterator<SongBean> itr=list.iterator();
						while(itr.hasNext())
						{
							SongBean song=(SongBean)itr.next();
							System.out.println(song);
						}
					}
				break;
				
			case 2:
				break;
				
			case 3:
				break;
				
			case 4:
				break;
				
			default:System.out.println("Enter Valid Option!");
					new UserUI().userMenu();
			}
			
		}
		catch(InputMismatchException e)
		{
			System.err.println("Enter Valid Option!");
		}
	}
	
	public static ArrayList<SongBean> searchSong()
	{	adminService=new AdminServiceImpl();
		ArrayList<SongBean> list=new ArrayList<>();
		System.out.println("1.Search Songs Based On Composer");
		System.out.println("2.Search Songs Based on Artist");
		System.out.println("Enter Choice: ");
		try
		{
			scanner=new Scanner(System.in);
			int choice=scanner.nextInt();
			switch(choice)
			{
			case 1:	System.out.print("Enter Composer Id: ");
					int composerId=scanner.nextInt();
					ComposerBean composer=adminService.searchComposer(composerId);
					if(composer!=null)
					{
						list=adminService.searchComposerSongAssoc(composerId);
					}else
						return null;
						//System.out.println("Composer Does Not Exists!");
					break;
			case 2:	System.out.print("Enter Artist Id: ");
					int artistId=scanner.nextInt();
					ArtistBean artist=adminService.searchArtist(artistId);
					if(artist!=null)
					{
						//list=adminService.searchArtistSongAssoc(artistId);
					}else
						System.out.println("Artist Does Not Exists!");
				break;
			default:System.out.println("Please enter a valid option!");
			}
		}
		catch(InputMismatchException e)
		{
			System.err.println("Enter Digits Only!");
		}
		catch(AdminException e)
		{
			System.err.println(e);
		}
		return list;
		
	}
}
