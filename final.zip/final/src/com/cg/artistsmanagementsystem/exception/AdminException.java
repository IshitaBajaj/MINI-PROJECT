package com.cg.artistsmanagementsystem.exception;

public class AdminException extends Exception {
	
	public AdminException(String message)
	{
		
		super(message);
	}

}
