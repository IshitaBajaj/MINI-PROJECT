package com.cg.artistsmanagementsystem.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.artistsmanagementsystem.bean.ArtistBean;
import com.cg.artistsmanagementsystem.bean.ComposerBean;
import com.cg.artistsmanagementsystem.bean.SongBean;
import com.cg.artistsmanagementsystem.bean.UserBean;
import com.cg.artistsmanagementsystem.dao.DaoAdminImpl;
import com.cg.artistsmanagementsystem.dao.DaoUserImpl;
import com.cg.artistsmanagementsystem.dao.IDaoAdmin;
import com.cg.artistsmanagementsystem.exception.AdminException;
import com.cg.artistsmanagementsystem.exception.UserException;

public class AdminServiceImpl implements IAdminService {
	IDaoAdmin adminDao=null;
	@Override
	public String login(UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		
		String type=adminDao.login(admin);
		return type;
		
	}
	
	@Override
	public ComposerBean searchComposer(int composerId) throws AdminException {
		adminDao=new DaoAdminImpl();
		ComposerBean composer=adminDao.searchComposer(composerId);	
		return composer;
	}
	@Override
	public int addComposer(ComposerBean composer, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		int id=adminDao.addComposer(composer,admin);
		return id;
	}
	@Override
	public boolean validateName(String name) {
		Pattern p=Pattern.compile("[A-Za-z ]{1,50}");
		Matcher m=p.matcher(name);
		boolean status=m.matches();
		return status;
	}
	@Override
	public boolean validateDate(String bornDate) {
		boolean status=true;
		if("NA".equals(bornDate))
			return status;
		else
		{
			Pattern p=Pattern.compile("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)");
			Matcher m=p.matcher(bornDate);
			status=m.matches();
		}
		return status;
	}
	@Override
	public boolean validateCaeipiNumber(String number) {
		Pattern p=Pattern.compile("[0-9A-Z]{1,10}");
		Matcher m=p.matcher(number);
		boolean status=m.matches();
		return status;
	}

	@Override
	public ArtistBean searchArtist(int artistId) throws AdminException {
		adminDao=new DaoAdminImpl();
		ArtistBean artist=adminDao.searchArtist(artistId);
		return artist;
	}

	@Override
	public int addArtist(ArtistBean artist, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		int id=adminDao.addArtist(artist,admin);
		return id;
	}

	@Override
	public boolean validateType(String type) {
		Pattern p=Pattern.compile("[a-zA-Z]");
		Matcher m=p.matcher(type);
		boolean status=m.matches();
		return status;
	}

	@Override
	public boolean updateComposerName(ComposerBean composer, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateComposerName(composer,admin);
		return status;
	}

	@Override
	public boolean updateComposerBornDate(ComposerBean composer, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateComposerBornDate(composer,admin);
		return status;
	}

	@Override
	public boolean updateComposerDiedDate(ComposerBean composer, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateComposerDiedDate(composer,admin);
		return status;
	}

	@Override
	public boolean updateComposerCaeipiNumber(ComposerBean composer,
			UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateComposerCaeipiNumber(composer,admin);
		return status;
	}

	@Override
	public boolean updateComposerMusicSocietyId(ComposerBean composer,
			UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateComposerMusicSocietyId(composer,admin);
		return status;
	}

	@Override
	public boolean updateArtistName(ArtistBean artist, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateArtistName(artist,admin);
		return status;
	}

	@Override
	public boolean updateArtistType(ArtistBean artist, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateArtistType(artist,admin);
		return status;
	}

	@Override
	public boolean updateArtistBornDate(ArtistBean artist, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateArtistBornDate(artist,admin);
		return status;
	}

	@Override
	public boolean updateArtistDiedDate(ArtistBean artist, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.updateArtistDiedDate(artist,admin);
		return status;
	}

	@Override
	public boolean searchSong(int songId) {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.searchSong(songId);
		return status;
	}

	@Override
	public boolean associateComposer(int composerId, int songId, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.associateComposer(composerId,songId,admin);
		return status;
	}

	@Override
	public boolean associateArtist(int artistId, int songId, UserBean admin) throws AdminException {
		adminDao=new DaoAdminImpl();
		boolean status=adminDao.associateArtist(artistId,songId,admin);
		return status;	
		}

	@Override
	public int validateDates(String bornDate, String diedDate) {
		int check=0;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String today=LocalDate.now().format(formatter);
		LocalDate t=LocalDate.parse(today, formatter);
		LocalDate d1=LocalDate.parse(bornDate, formatter);
		if((t.compareTo(d1))>0)
			if(diedDate!=null)
			{
				LocalDate d2=LocalDate.parse(diedDate, formatter);
				if(d2.compareTo(d1)>0)
				{
					check=0;
				}
			}
			else 
				check=1;
		
		return check;
	}

	@Override
	public boolean validateMusicSociety(String societyId) {
		if("000".equals(societyId)||"100".equals(societyId)||"101".equals(societyId))
			return true;
		else
			return false;
	}

	@Override
	public ArrayList<Integer> getComposerList() throws AdminException {
		adminDao=new DaoAdminImpl();
		ArrayList<Integer> composerList=adminDao.getComposerList();	
		return composerList;
	}

	@Override
	public ArrayList<Integer> getArtistList() throws AdminException {
		adminDao=new DaoAdminImpl();
		ArrayList<Integer> artistList=adminDao.getArtistList();	
		return artistList;
	}

	
public boolean validateNumber(String number) {
		
		Matcher match=null;
		Pattern patt=Pattern.compile("[0-9]{1,6}");    
		match=patt.matcher(number);
		if(match.matches()==false){
			
			System.out.flush();
			System.err.println("Invalid Id! Maximum Length Must Be 6! Try Again");
			
		}
		return match.matches();
	}
}
