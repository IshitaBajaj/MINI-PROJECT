/**
 * 
 */
package com.cg.artistsmanagementsystem.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.artistsmanagementsystem.bean.ArtistBean;
import com.cg.artistsmanagementsystem.bean.ComposerBean;
import com.cg.artistsmanagementsystem.bean.UserBean;
import com.cg.artistsmanagementsystem.dao.DaoAdminImpl;
import com.cg.artistsmanagementsystem.dao.IDaoAdmin;
import com.cg.artistsmanagementsystem.exception.AdminException;

/**
 * @author ibajaj
 *
 */
public class DaoAdminImplTest {

	IDaoAdmin adminDao=new DaoAdminImpl();
	
	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#login(com.cg.artistsmanagementsystem.bean.UserBean)}.
	 * @throws AdminException 
	 */
	@Test
	public void testLogin() throws AdminException {
		UserBean user=new UserBean(155201,"user");
		assertEquals("U",adminDao.login(user));
		
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#searchComposer(int)}.
	 * @throws AdminException 
	 */
	@Test
	public void testSearchComposer() throws AdminException {
		int composerId=123456;
		assertEquals(null,adminDao.searchComposer(composerId));
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#addComposer(com.cg.artistsmanagementsystem.bean.ComposerBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 * @throws AdminException 
	 */
	@Test
	public void testAddComposer() throws AdminException {
		ComposerBean composer=new ComposerBean();
		composer.setComposerName("COMPOSER");
		composer.setComposerBornDate("02/06/1965");
		composer.setComposerDiedDate("09/01/2018");
		composer.setComposerCaeipiNumber("123456ABCD");
		composer.setComposerMusicSocietyID("100");
		
		UserBean admin=new UserBean(155201,"admin");
		assertNotEquals(-1,adminDao.addComposer(composer, admin));
		
		
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#searchArtist(int)}.
	 * @throws AdminException 
	 */
	@Test
	public void testSearchArtist() throws AdminException {
		int artistId=123456;
		assertEquals(null,adminDao.searchArtist(artistId));
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#addArtist(com.cg.artistsmanagementsystem.bean.ArtistBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 * @throws AdminException 
	 */
	@Test
	public void testAddArtist() throws AdminException {
		ArtistBean artist=new ArtistBean();
		artist.setArtistName("ARTIST");
		artist.setArtistBornDate("09/09/1965");
		artist.setArtistDiedDate("09/09/1999");
		artist.setArtistType("T");
		UserBean admin=new UserBean(155201,"admin");
		assertNotEquals(-1,adminDao.addArtist(artist, admin));
		
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateComposerName(com.cg.artistsmanagementsystem.bean.ComposerBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateComposerName() {
		ComposerBean composer=new ComposerBean();
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateComposerBornDate(com.cg.artistsmanagementsystem.bean.ComposerBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateComposerBornDate() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateComposerDiedDate(com.cg.artistsmanagementsystem.bean.ComposerBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateComposerDiedDate() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateComposerCaeipiNumber(com.cg.artistsmanagementsystem.bean.ComposerBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateComposerCaeipiNumber() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateComposerMusicSocietyId(com.cg.artistsmanagementsystem.bean.ComposerBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateComposerMusicSocietyId() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateArtistName(com.cg.artistsmanagementsystem.bean.ArtistBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateArtistName() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateArtistType(com.cg.artistsmanagementsystem.bean.ArtistBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateArtistType() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateArtistBornDate(com.cg.artistsmanagementsystem.bean.ArtistBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateArtistBornDate() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#updateArtistDiedDate(com.cg.artistsmanagementsystem.bean.ArtistBean, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testUpdateArtistDiedDate() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#searchSong(int)}.
	 */
	@Test
	public void testSearchSong() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#associateComposer(int, int, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testAssociateComposer() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cg.artistsmanagementsystem.dao.DaoAdminImpl#associateArtist(int, int, com.cg.artistsmanagementsystem.bean.UserBean)}.
	 */
	@Test
	public void testAssociateArtist() {
		fail("Not yet implemented");
	}

}
