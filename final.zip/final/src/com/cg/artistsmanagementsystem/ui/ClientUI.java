package com.cg.artistsmanagementsystem.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.artistsmanagementsystem.bean.UserBean;
import com.cg.artistsmanagementsystem.exception.AdminException;
import com.cg.artistsmanagementsystem.service.AdminServiceImpl;
import com.cg.artistsmanagementsystem.service.IAdminService;
import com.cg.artistsmanagementsystem.service.IUserService;
import com.cg.artistsmanagementsystem.service.UserServiceImpl;

public class ClientUI {

	public static void main(String[] args) {
		
		int option;
		char choice='y';
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("*******************************************************************");
		System.out.println("           MEDIA COMPOSER AND ARTISTS MANAGEMENT SYSTEM");
		System.out.println("******************************************************************");
		System.out.println("Menu:");
		System.out.println("1.Login");
		System.out.println("2.Exit");
		
		do
		{
			try
			{
			System.out.print("Enter Your Choice:");
			option=(int)scanner.nextInt();
			
			switch(option)
			{
				case 1:	IAdminService adminService=new AdminServiceImpl();
						try{
							System.out.print("Enter Login Id: ");
							int id=scanner.nextInt();
							System.out.print("Enter Password: ");
							String pwd=scanner.next();
							UserBean user=new UserBean();
						
							user.setUserId(id);
							user.setUserPwd(pwd);
							String type=adminService.login(user);
							if("A".equals(type))
							{
								System.out.println("Login Successful!");
								new AdminUI(user).adminMenu();
							}
							else if("U".equals(type)){
								System.out.println("Login Successful!");
								new UserUI().userMenu();
							}
							else
							{	System.out.flush();
								System.err.flush();
								System.err.println("Invalid Username/Password!");
							}
						}
						catch(InputMismatchException e)
						{	System.err.flush();
							System.err.println("Enter Integer Only!\n");
						}catch (Exception e) {
							e.printStackTrace();
							System.err.flush();
							System.err.println(e);;
						}
						
						break;
				
				case 2: System.out.println("Application Terminated!");
						System.exit(0);
						break;
				default:System.err.print("Please Enter a Valid Option!\n");		
						ClientUI.main(null);
			}
			scanner.nextLine();
			}
			catch(InputMismatchException e)
			{
				System.out.flush();
				System.err.println("Please Enter a Valid Option!");
				scanner.next();
				ClientUI.main(null);
				
			}
			
			System.out.print("Do you want to continue? Press 'N' to exit else to continue. ");
			choice=scanner.next().charAt(0);
					}while(choice!='N'&&choice!='n');
}
	


}
